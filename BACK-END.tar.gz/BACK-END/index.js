/*
(async () => {
  const db = require("./db");
  console.log("Começou!");

  console.log("SELECT * FROM CLIENTES");
  const prod = await db.selectProdutos();
  console.log(prod);
})();
*/

(async () => {
  const db = require("./db");
  console.log("Começou!");

  console.log("Exemplo de Update no MySQL pelo Back-end"); // 2º
  const result = await db.updateProdutos(2, {
    descricao: "Cadeira Giratória",
    quantidade: 12,
  });
  console.log(result);
})();