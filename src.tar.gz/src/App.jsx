
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Ola React</h1>
      /br
      <p>Meu Segundo App</p>
    </div>
  );

export default App;
